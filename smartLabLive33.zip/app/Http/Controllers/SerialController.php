<?php

namespace App\Http\Controllers;

use App\Models\Serial;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;

class SerialController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Serial  $serial
     * @return \Illuminate\Http\Response
     */
    public function show(Serial $serial)
    {
        //
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Serial  $serial
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Serial $serial)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Serial  $serial
     * @return \Illuminate\Http\Response
     */
    public function destroy(Serial $serial)
    {
        //
    }


    public function check(Request $request)
    {
        $uiid = $request->uiid;
        $bios = $request->bios;

        $serial = DB::table('serials')->where('serial', $request->serial)->where('active', true)->first();
        if ($serial) {
            $identifiers =  json_decode($serial->identifiers);
            if ($identifiers) {
                foreach ($identifiers as $identifier) {
                    if ($identifier->uiid == $uiid || $identifier->bios == $bios) {
                        return response(['status' => true, 'message' => 'Valid'], Response::HTTP_OK);
                    }
                }
            }
        }

        return response(['status' => false, 'message' => 'Invalid Serial - Expired licence'], Response::HTTP_NON_AUTHORITATIVE_INFORMATION);
    }

    public function active(Request $request)
    {
        $uiid = (str_replace(' ', '', $request->uiid)) ? $request->uiid : 'XX##UIID'. rand(1000000,100000000);
        $bios = (str_replace(' ','', $request->bios)) ? $request->bios : 'XX##BIOS'. rand(1000000,100000000);

        $serial =  DB::table('serials')->where('serial', $request->serial)->where('active', true)->first();

        if ($serial) {
            $maxUsers = $serial->maxUsers;
            $identifiers =  json_decode($serial->identifiers);
            if ($identifiers) {
                if (count($identifiers) < $maxUsers) {
                    $identifier = [
                        'uiid' => $uiid,
                        'bios' => $bios
                    ];

                    // Check If this device founded => no action . onley activate
                    $founded = true;
                    foreach ($identifiers as $e) {
                        if ($e->uiid == $uiid || $e->uiid == $bios) {
                            $founded = true;
                        }
                    }
                    if(!$founded) {
                        $identifiers[] = $identifier;
                        $identifiers = json_encode($identifiers);
                        DB::table('serials')->where('id', $serial->id)->update(['identifiers' => $identifiers]);
                    }

                    return response(['status' => true, 'message' => 'Valid 1'], Response::HTTP_OK);
                }
            } else {
                $identifier = [
                    'uiid' => $uiid,
                    'bios' => $bios
                ];
                $identifiers = json_encode(array($identifier));
                DB::table('serials')->where('id', $serial->id)->update(['identifiers' => $identifiers]);
                return response(['status' => true, 'message' => 'Valid'], Response::HTTP_OK);
            }
            return response(['status' => false, 'message' => 'Serial already used'], Response::HTTP_ALREADY_REPORTED);
        }
        return response(['status' => false, 'message' => 'Invalid Serial'], Response::HTTP_OK);
    }
}
